# NestJs Youtube playlist

This repo is for this playlist on youtube... [here](https://www.youtube.com/watch?v=J9I1aDoWeNo&list=PLM0LBHjz37LVfT_McvhvKtRoVBk6riWEj)

<img src="Nest_js.png" />

## Installation

```bash
$ npm install
```

## Running the app

```bash
# development
$ npm run start

# watch mode
$ npm run start:dev

# production mode
$ npm run start:prod
```
