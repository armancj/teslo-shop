export const env = {
  ENVIRONMENT: 'dev',
  APP_PORT: 3000,
  DB_HOSTNAME: 'localhost',
  DB_PORT: 3306,
  DB_DATABASE: 'nestjs_template',
  DB_USERNAME: 'root',
  DB_PASSWORD: 'root',
  JWT_SECRET: 'secret',
  JWT_EXPIRES_IN: '7d'
}