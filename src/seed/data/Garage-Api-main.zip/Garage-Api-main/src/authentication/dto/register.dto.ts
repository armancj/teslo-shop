export class RegisterDto {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  address: string;
  dayofbirth: string;
  gender: string;
  phoneNumber: string;
}

export default RegisterDto;
