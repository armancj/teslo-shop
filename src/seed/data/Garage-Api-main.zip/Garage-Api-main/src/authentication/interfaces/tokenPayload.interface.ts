export default interface TokenPayload {
  userId: number;
}
