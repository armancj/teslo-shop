enum Role {
    Guest = 'Guest',
    Admin = 'Admin',
    Employee = 'Employee',
  }
   
  export default Role;