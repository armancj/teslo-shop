export class CreateReservationDto {
  r_date: string;
  service: any;
  userId: number;
  statusId: number;
}

export default CreateReservationDto;
