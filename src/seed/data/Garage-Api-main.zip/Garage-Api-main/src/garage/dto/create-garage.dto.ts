export class GarageDto {
  name: string;
}

export default GarageDto;
