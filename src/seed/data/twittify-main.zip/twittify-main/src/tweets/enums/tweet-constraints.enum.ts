export enum TweetConstraints {
  TweetMaxLength = 140,
  TweetMinLength = 4
}
