export enum NodeEnv {
  Development = `development`,
  Production = `production`,
  Staging = `staging`,
  Test = `test`
}
