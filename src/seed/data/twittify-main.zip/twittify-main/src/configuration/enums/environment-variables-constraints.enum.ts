export enum EnvironmentVariablesConstraints {
  MaximumJwtSecretLength = 64,
  MinimumJwtSecretLength = 32
}
