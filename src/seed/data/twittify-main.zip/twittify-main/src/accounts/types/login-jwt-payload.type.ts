export type LoginJwtPayload = {
  email: string
  sub: number
}
