export enum PassportStrategies {
  Jwt = `Jwt`,
  Local = `Local`
}
