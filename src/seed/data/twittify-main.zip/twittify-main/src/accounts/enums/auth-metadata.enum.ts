export enum AuthMetadata {
  IsPublicRoute = `IsPublicRoute`
}
