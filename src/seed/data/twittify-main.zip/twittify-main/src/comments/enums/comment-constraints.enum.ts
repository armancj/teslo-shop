export enum CommentConstraints {
  ContentMaxLength = 140,
  ContentMinLength = 2
}
