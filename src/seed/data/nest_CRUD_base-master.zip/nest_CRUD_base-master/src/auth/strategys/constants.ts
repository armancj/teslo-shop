export const jwtConstants = {
    secret: 'secretKey',
    livetime: 60*60
  };
  