export interface IMailSendResponse {
  status: number;
  message: string;
}
