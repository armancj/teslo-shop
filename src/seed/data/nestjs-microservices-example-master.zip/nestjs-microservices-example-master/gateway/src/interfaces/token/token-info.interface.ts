export interface ITokenInfo {
  data: {
    userId: string;
  };
}
