export const userSignupRequestSuccess = {
  email: 'test@denrox.com',
  password: 'test111',
};
