export const taskUpdateRequestSuccess = {
  name: 'test task (updated)',
  description: 'some description for the test task (updated)',
  start_time: 1569357602568,
  duration: 900001,
  is_solved: true,
};
