export const taskCreateRequestSuccess = {
  name: 'test task',
  description: 'some description for the test task',
  start_time: 1569357602567,
  duration: 900000,
};
