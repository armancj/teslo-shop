export interface IUser {
  id?: string;
  email: string;
  is_confirmed: boolean;
}
