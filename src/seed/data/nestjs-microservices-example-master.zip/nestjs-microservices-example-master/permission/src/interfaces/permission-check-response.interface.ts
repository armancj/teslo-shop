export interface IPermissionCheckResponse {
  status: number;
  message: string;
  errors: null;
}
