export const permissions = [
  'user_get_by_id',
  'user_confirm',
  'task_search_by_user_id',
  'task_create',
  'task_delete_by_id',
  'task_update_by_id',
];
