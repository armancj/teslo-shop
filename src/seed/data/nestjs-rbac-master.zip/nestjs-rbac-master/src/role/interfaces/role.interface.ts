export interface IRole {
    role: string;
}
